package edu.utsa.cs3443.projectplanner.controller;

import android.content.res.AssetManager;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import edu.utsa.cs3443.projectplanner.MainActivity;
import edu.utsa.cs3443.projectplanner.model.Objective;

public class MainController {
    public MainController(MainActivity activity) throws IOException {

        ArrayList<Objective> objectives= new ArrayList<Objective>();
        //loops through all asset files and
        AssetManager manager = activity.getAssets();
        Scanner scan = null;
        String fileList[] = manager.list("");
        int i=0;
        for (String fileName : fileList) {
            if (fileName.endsWith(".prj")){
                //open the file read the name, create Objective object and add to arraylist
                scan = new Scanner(fileName);
                Objective o = new Objective(scan.nextLine(),i,fileName,activity);
                objectives.add(o);
                //assign button text to title;
                
            }
            i++;
            if(i>=4){
                break;
            }
        }

    }
}
